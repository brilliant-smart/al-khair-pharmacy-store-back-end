<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // API returns 401, web redirects to login
        $middleware->redirectGuestsTo(function ($request) {
            return $request->expectsJson() ? null : '/login';
        });
        
        // Register middleware aliases
        $middleware->alias([
            'hide.profit' => \App\Http\Middleware\HideProfitData::class,
            'auth.token' => \App\Http\Middleware\AuthenticateWithToken::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
