-- Database Backup
-- Created: 2026-03-02 20:01:46
-- Database: alkhair_store

SET FOREIGN_KEY_CHECKS=0;

-- Table: api_keys
DROP TABLE IF EXISTS `api_keys`;
CREATE TABLE `api_keys` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_keys_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: audit_logs
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_created_at_index` (`created_at`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: auto_reorder_logs
DROP TABLE IF EXISTS `auto_reorder_logs`;
CREATE TABLE `auto_reorder_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `current_stock` int(11) NOT NULL,
  `reorder_point` int(11) NOT NULL,
  `suggested_quantity` int(11) NOT NULL,
  `suggested_supplier_id` bigint(20) unsigned DEFAULT NULL,
  `action_taken` enum('po_created','notification_sent','ignored','manual_override') NOT NULL DEFAULT 'notification_sent',
  `purchase_order_id` bigint(20) unsigned DEFAULT NULL,
  `triggered_by` bigint(20) unsigned DEFAULT NULL,
  `triggered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auto_reorder_logs_suggested_supplier_id_foreign` (`suggested_supplier_id`),
  KEY `auto_reorder_logs_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `auto_reorder_logs_triggered_by_foreign` (`triggered_by`),
  KEY `auto_reorder_logs_product_id_triggered_at_index` (`product_id`,`triggered_at`),
  KEY `auto_reorder_logs_action_taken_index` (`action_taken`),
  CONSTRAINT `auto_reorder_logs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auto_reorder_logs_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `auto_reorder_logs_suggested_supplier_id_foreign` FOREIGN KEY (`suggested_supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `auto_reorder_logs_triggered_by_foreign` FOREIGN KEY (`triggered_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: cache
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cache` VALUES ('laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab', 'i:2;', '1772481748');
INSERT INTO `cache` VALUES ('laravel-cache-356a192b7913b04c54574d18c28d46e6395428ab:timer', 'i:1772481748;', '1772481748');
INSERT INTO `cache` VALUES ('laravel-cache-5c785c036466adea360111aa28563bfd556b5fba', 'i:1;', '1772481684');
INSERT INTO `cache` VALUES ('laravel-cache-5c785c036466adea360111aa28563bfd556b5fba:timer', 'i:1772481684;', '1772481684');
INSERT INTO `cache` VALUES ('laravel-cache-77de68daecd823babbb58edb1c8e14d7106e83bb', 'i:2;', '1772399182');
INSERT INTO `cache` VALUES ('laravel-cache-77de68daecd823babbb58edb1c8e14d7106e83bb:timer', 'i:1772399182;', '1772399182');

-- Table: cache_locks
DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: cart_items
DROP TABLE IF EXISTS `cart_items`;
CREATE TABLE `cart_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_items_product_id_foreign` (`product_id`),
  KEY `cart_items_customer_id_product_id_index` (`customer_id`,`product_id`),
  KEY `cart_items_session_id_index` (`session_id`),
  CONSTRAINT `cart_items_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: controlled_substance_logs
DROP TABLE IF EXISTS `controlled_substance_logs`;
CREATE TABLE `controlled_substance_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `transaction_type` enum('received','dispensed','destroyed','returned','transfer') NOT NULL,
  `quantity` int(11) NOT NULL,
  `balance_before` int(11) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `prescription_id` bigint(20) unsigned DEFAULT NULL,
  `patient_name` varchar(255) DEFAULT NULL,
  `patient_id_type` varchar(255) DEFAULT NULL,
  `patient_id_number` varchar(255) DEFAULT NULL,
  `dispensed_by` bigint(20) unsigned NOT NULL,
  `verified_by` bigint(20) unsigned DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `controlled_substance_logs_prescription_id_foreign` (`prescription_id`),
  KEY `controlled_substance_logs_dispensed_by_foreign` (`dispensed_by`),
  KEY `controlled_substance_logs_verified_by_foreign` (`verified_by`),
  KEY `controlled_substance_logs_product_id_transaction_date_index` (`product_id`,`transaction_date`),
  KEY `controlled_substance_logs_transaction_type_index` (`transaction_type`),
  CONSTRAINT `controlled_substance_logs_dispensed_by_foreign` FOREIGN KEY (`dispensed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `controlled_substance_logs_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `controlled_substance_logs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `controlled_substance_logs_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: coupon_usages
DROP TABLE IF EXISTS `coupon_usages`;
CREATE TABLE `coupon_usages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `discount_amount` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_usages_customer_id_foreign` (`customer_id`),
  KEY `coupon_usages_order_id_foreign` (`order_id`),
  KEY `coupon_usages_coupon_id_customer_id_index` (`coupon_id`,`customer_id`),
  CONSTRAINT `coupon_usages_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_usages_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `coupon_usages_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: coupons
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('percentage','fixed_amount','free_shipping') NOT NULL,
  `value` decimal(15,2) NOT NULL,
  `min_order_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `max_discount_amount` decimal(15,2) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `usage_limit_per_customer` int(11) NOT NULL DEFAULT 1,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `applicable_products` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`applicable_products`)),
  `applicable_categories` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`applicable_categories`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`),
  KEY `coupons_code_index` (`code`),
  KEY `coupons_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: crm_settings
DROP TABLE IF EXISTS `crm_settings`;
CREATE TABLE `crm_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `loyalty_program_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `points_per_currency` int(11) NOT NULL DEFAULT 1,
  `currency_per_point` decimal(10,2) NOT NULL DEFAULT 0.10,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `crm_settings` VALUES ('1', '0', '0', '1', '0.10', '2026-02-23 20:01:42', '2026-02-23 20:01:42');

-- Table: customer_addresses
DROP TABLE IF EXISTS `customer_addresses`;
CREATE TABLE `customer_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `label` varchar(255) NOT NULL DEFAULT 'Home',
  `address_line1` varchar(255) NOT NULL,
  `address_line2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'Nigeria',
  `postal_code` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_addresses_customer_id_foreign` (`customer_id`),
  CONSTRAINT `customer_addresses_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: customer_loyalty_points
DROP TABLE IF EXISTS `customer_loyalty_points`;
CREATE TABLE `customer_loyalty_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `lifetime_points` int(11) NOT NULL DEFAULT 0,
  `tier` varchar(255) NOT NULL DEFAULT 'bronze',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_loyalty_points_customer_id_unique` (`customer_id`),
  CONSTRAINT `customer_loyalty_points_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: customer_notes
DROP TABLE IF EXISTS `customer_notes`;
CREATE TABLE `customer_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` enum('note','call','email','meeting','complaint','feedback') NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `interaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_notes_user_id_foreign` (`user_id`),
  KEY `customer_notes_customer_id_created_at_index` (`customer_id`,`created_at`),
  CONSTRAINT `customer_notes_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: customer_segment_members
DROP TABLE IF EXISTS `customer_segment_members`;
CREATE TABLE `customer_segment_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `segment_id` bigint(20) unsigned NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_segment_members_customer_id_segment_id_unique` (`customer_id`,`segment_id`),
  KEY `customer_segment_members_segment_id_foreign` (`segment_id`),
  CONSTRAINT `customer_segment_members_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_segment_members_segment_id_foreign` FOREIGN KEY (`segment_id`) REFERENCES `customer_segments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: customer_segments
DROP TABLE IF EXISTS `customer_segments`;
CREATE TABLE `customer_segments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `criteria` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`criteria`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: customers
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_number` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_customer_number_unique` (`customer_number`),
  UNIQUE KEY `customers_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: departments
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `departments` VALUES ('1', 'Pharmacy', 'pharmacy', NULL, NULL);
INSERT INTO `departments` VALUES ('2', 'Superstore', 'superstore', NULL, NULL);
INSERT INTO `departments` VALUES ('3', 'Electronics & Kitchen', 'electronics-kitchen', NULL, NULL);
INSERT INTO `departments` VALUES ('4', 'Textiles & Materials', 'textiles', NULL, NULL);
INSERT INTO `departments` VALUES ('5', 'Baby Care', 'baby-care', NULL, NULL);
INSERT INTO `departments` VALUES ('6', 'Wholesale', 'wholesale', NULL, NULL);

-- Table: ecommerce_settings
DROP TABLE IF EXISTS `ecommerce_settings`;
CREATE TABLE `ecommerce_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `online_payment_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `delivery_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `guest_checkout_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `min_order_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `terms_and_conditions` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `ecommerce_settings` VALUES ('1', '0', '0', '0', '1', '0.00', NULL, '2026-02-23 19:58:38', '2026-02-23 19:58:38');

-- Table: email_campaigns
DROP TABLE IF EXISTS `email_campaigns`;
CREATE TABLE `email_campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` enum('draft','scheduled','sending','sent','cancelled') NOT NULL DEFAULT 'draft',
  `segment_id` bigint(20) unsigned DEFAULT NULL,
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `recipients_count` int(11) NOT NULL DEFAULT 0,
  `sent_count` int(11) NOT NULL DEFAULT 0,
  `opened_count` int(11) NOT NULL DEFAULT 0,
  `clicked_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_campaigns_segment_id_foreign` (`segment_id`),
  CONSTRAINT `email_campaigns_segment_id_foreign` FOREIGN KEY (`segment_id`) REFERENCES `customer_segments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: integration_settings
DROP TABLE IF EXISTS `integration_settings`;
CREATE TABLE `integration_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `provider` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `credentials` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`credentials`)),
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  `last_sync_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integration_settings_provider_unique` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: inventory_cycle_count_items
DROP TABLE IF EXISTS `inventory_cycle_count_items`;
CREATE TABLE `inventory_cycle_count_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cycle_count_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `expected_quantity` int(11) NOT NULL,
  `actual_quantity` int(11) NOT NULL,
  `variance` int(11) GENERATED ALWAYS AS (`actual_quantity` - `expected_quantity`) STORED,
  `unit_cost` decimal(15,2) NOT NULL,
  `variance_value` decimal(15,2) GENERATED ALWAYS AS ((`actual_quantity` - `expected_quantity`) * `unit_cost`) STORED,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_cycle_count_items_product_id_foreign` (`product_id`),
  KEY `inventory_cycle_count_items_cycle_count_id_product_id_index` (`cycle_count_id`,`product_id`),
  CONSTRAINT `inventory_cycle_count_items_cycle_count_id_foreign` FOREIGN KEY (`cycle_count_id`) REFERENCES `inventory_cycle_counts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_cycle_count_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: inventory_cycle_counts
DROP TABLE IF EXISTS `inventory_cycle_counts`;
CREATE TABLE `inventory_cycle_counts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `count_number` varchar(255) NOT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `counted_by` bigint(20) unsigned NOT NULL,
  `verified_by` bigint(20) unsigned DEFAULT NULL,
  `status` enum('in_progress','completed','verified','cancelled') NOT NULL DEFAULT 'in_progress',
  `count_date` date NOT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_cycle_counts_count_number_unique` (`count_number`),
  KEY `inventory_cycle_counts_department_id_foreign` (`department_id`),
  KEY `inventory_cycle_counts_counted_by_foreign` (`counted_by`),
  KEY `inventory_cycle_counts_verified_by_foreign` (`verified_by`),
  KEY `inventory_cycle_counts_count_number_index` (`count_number`),
  KEY `inventory_cycle_counts_status_index` (`status`),
  CONSTRAINT `inventory_cycle_counts_counted_by_foreign` FOREIGN KEY (`counted_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_cycle_counts_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_cycle_counts_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: ip_whitelist
DROP TABLE IF EXISTS `ip_whitelist`;
CREATE TABLE `ip_whitelist` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_whitelist_ip_address_unique` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: job_batches
DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: jobs
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: login_attempts
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `successful` tinyint(1) NOT NULL DEFAULT 0,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_attempts_email_attempted_at_index` (`email`,`attempted_at`),
  KEY `login_attempts_ip_address_index` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: loyalty_transactions
DROP TABLE IF EXISTS `loyalty_transactions`;
CREATE TABLE `loyalty_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `type` enum('earned','redeemed','expired','adjusted') NOT NULL,
  `points` int(11) NOT NULL,
  `balance_before` int(11) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loyalty_transactions_order_id_foreign` (`order_id`),
  KEY `loyalty_transactions_customer_id_created_at_index` (`customer_id`,`created_at`),
  KEY `loyalty_transactions_type_index` (`type`),
  CONSTRAINT `loyalty_transactions_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `loyalty_transactions_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('1', '0001_01_01_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('2', '0001_01_01_000001_create_cache_table', '1');
INSERT INTO `migrations` VALUES ('3', '0001_01_01_000002_create_jobs_table', '1');
INSERT INTO `migrations` VALUES ('4', '2026_01_07_213407_create_departments_table', '1');
INSERT INTO `migrations` VALUES ('5', '2026_01_07_213423_add_role_and_department_to_users_table', '1');
INSERT INTO `migrations` VALUES ('6', '2026_01_07_213443_create_products_table', '1');
INSERT INTO `migrations` VALUES ('7', '2026_01_10_135933_create_personal_access_tokens_table', '1');
INSERT INTO `migrations` VALUES ('8', '2026_01_11_143240_add_is_active_to_users_table', '1');
INSERT INTO `migrations` VALUES ('9', '2026_02_13_202453_add_slug_and_price_to_products_table', '1');
INSERT INTO `migrations` VALUES ('10', '2026_02_15_195311_add_is_featured_to_products_table', '1');
INSERT INTO `migrations` VALUES ('11', '2026_02_16_162653_add_avatar_url_to_users_table', '1');
INSERT INTO `migrations` VALUES ('12', '2026_02_17_141100_add_inventory_fields_to_products_table', '1');
INSERT INTO `migrations` VALUES ('13', '2026_02_17_141200_create_stock_movements_table', '1');
INSERT INTO `migrations` VALUES ('14', '2026_02_18_131856_add_soft_deletes_to_products_table', '1');
INSERT INTO `migrations` VALUES ('15', '2026_02_18_170119_create_suppliers_table', '1');
INSERT INTO `migrations` VALUES ('16', '2026_02_18_170124_create_purchase_orders_table', '1');
INSERT INTO `migrations` VALUES ('17', '2026_02_18_170126_create_purchase_order_items_table', '1');
INSERT INTO `migrations` VALUES ('18', '2026_02_18_170128_create_sales_table', '1');
INSERT INTO `migrations` VALUES ('19', '2026_02_18_170129_create_sale_items_table', '1');
INSERT INTO `migrations` VALUES ('20', '2026_02_18_170411_add_cost_tracking_to_products_table', '1');
INSERT INTO `migrations` VALUES ('21', '2026_02_19_131836_add_barcode_to_products_table', '2');
INSERT INTO `migrations` VALUES ('22', '2026_02_19_144500_make_department_id_nullable_in_sales_table', '3');
INSERT INTO `migrations` VALUES ('23', '2026_02_19_174500_make_department_id_nullable_in_purchase_orders_table', '4');
INSERT INTO `migrations` VALUES ('24', '2026_02_19_180000_add_payment_fields_to_purchase_orders_table', '5');
INSERT INTO `migrations` VALUES ('25', '2026_02_22_135226_add_unit_type_to_products_sale_items_and_purchase_order_items_table', '6');
INSERT INTO `migrations` VALUES ('26', '2026_02_23_192500_update_payment_terms_enum_in_suppliers_table', '7');
INSERT INTO `migrations` VALUES ('27', '2026_02_23_193000_add_expiry_and_batch_tracking_to_products', '8');
INSERT INTO `migrations` VALUES ('28', '2026_02_23_193100_create_product_batches_table', '8');
INSERT INTO `migrations` VALUES ('29', '2026_02_23_193200_create_stock_transfers_table', '8');
INSERT INTO `migrations` VALUES ('30', '2026_02_23_193300_create_inventory_cycle_counts_table', '8');
INSERT INTO `migrations` VALUES ('32', '2026_02_23_193400_create_auto_reorder_logs_table', '9');
INSERT INTO `migrations` VALUES ('33', '2026_02_23_194000_create_notifications_table', '10');
INSERT INTO `migrations` VALUES ('34', '2026_02_23_195000_create_prescriptions_table', '11');
INSERT INTO `migrations` VALUES ('35', '2026_02_23_195100_create_controlled_substances_table', '12');
INSERT INTO `migrations` VALUES ('36', '2026_02_23_195200_create_audit_logs_table', '12');
INSERT INTO `migrations` VALUES ('37', '2026_02_23_200000_create_ecommerce_tables', '13');
INSERT INTO `migrations` VALUES ('38', '2026_02_23_201000_create_crm_tables', '14');
INSERT INTO `migrations` VALUES ('39', '2026_02_23_202000_add_database_indexes', '15');
INSERT INTO `migrations` VALUES ('40', '2026_02_23_203000_create_security_tables', '16');
INSERT INTO `migrations` VALUES ('41', '2026_02_23_204000_create_integration_tables', '17');
INSERT INTO `migrations` VALUES ('42', '2026_02_23_205000_create_product_price_history_table', '18');
INSERT INTO `migrations` VALUES ('46', '2026_03_01_210000_add_reorder_level_to_products_table', '19');
INSERT INTO `migrations` VALUES ('47', '2026_02_27_224300_add_batch_tracking_to_purchase_order_items_table', '20');
INSERT INTO `migrations` VALUES ('48', '2026_02_27_224400_add_purchase_order_item_id_to_product_batches_table', '21');

-- Table: notification_logs
DROP TABLE IF EXISTS `notification_logs`;
CREATE TABLE `notification_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_logs_user_id_foreign` (`user_id`),
  KEY `notification_logs_type_status_index` (`type`,`status`),
  KEY `notification_logs_category_index` (`category`),
  CONSTRAINT `notification_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: notification_settings
DROP TABLE IF EXISTS `notification_settings`;
CREATE TABLE `notification_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `email_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `sms_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `in_app_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `recipients` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recipients`)),
  `threshold_value` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notification_settings` VALUES ('1', 'low_stock_alert', 'Low Stock Alert', 'Notify when product stock falls below reorder point', '1', '0', '1', NULL, NULL, '2026-02-23 19:55:18', '2026-02-23 19:55:18');
INSERT INTO `notification_settings` VALUES ('2', 'expiry_warning', 'Product Expiry Warning', 'Notify when products are expiring soon', '1', '0', '1', NULL, '30', '2026-02-23 19:55:18', '2026-02-23 19:55:18');
INSERT INTO `notification_settings` VALUES ('3', 'po_approval', 'Purchase Order Approval', 'Notify when purchase order needs approval', '1', '0', '1', NULL, NULL, '2026-02-23 19:55:18', '2026-02-23 19:55:18');
INSERT INTO `notification_settings` VALUES ('4', 'po_received', 'Purchase Order Received', 'Notify when purchase order is received', '1', '0', '1', NULL, NULL, '2026-02-23 19:55:18', '2026-02-23 19:55:18');
INSERT INTO `notification_settings` VALUES ('5', 'sale_created', 'Sale Created', 'Notify when a new sale is created', '0', '0', '1', NULL, NULL, '2026-02-23 19:55:18', '2026-02-23 19:55:18');
INSERT INTO `notification_settings` VALUES ('6', 'payment_reminder', 'Payment Reminder', 'Remind about pending payments', '1', '1', '1', NULL, NULL, '2026-02-23 19:55:18', '2026-02-23 19:55:18');

-- Table: order_items
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_sku` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: orders
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_phone` varchar(255) NOT NULL,
  `status` enum('pending','confirmed','processing','ready','completed','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `subtotal` decimal(15,2) NOT NULL,
  `tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `shipping_fee` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL,
  `payment_method` enum('cash','bank_transfer','card','online') DEFAULT NULL,
  `payment_status` enum('unpaid','paid','partially_paid','refunded') NOT NULL DEFAULT 'unpaid',
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_reference` varchar(255) DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT NULL,
  `requires_delivery` tinyint(1) NOT NULL DEFAULT 0,
  `delivery_address_id` bigint(20) unsigned DEFAULT NULL,
  `delivery_status` enum('pending','processing','shipped','delivered','failed') DEFAULT NULL,
  `tracking_number` varchar(255) DEFAULT NULL,
  `delivery_date` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `customer_notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_unique` (`order_number`),
  KEY `orders_delivery_address_id_foreign` (`delivery_address_id`),
  KEY `orders_order_number_index` (`order_number`),
  KEY `orders_customer_id_index` (`customer_id`),
  KEY `orders_status_index` (`status`),
  KEY `orders_payment_status_index` (`payment_status`),
  KEY `orders_created_at_index` (`created_at`),
  KEY `orders_customer_id_status_index` (`customer_id`,`status`),
  KEY `orders_status_created_at_index` (`status`,`created_at`),
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_delivery_address_id_foreign` FOREIGN KEY (`delivery_address_id`) REFERENCES `customer_addresses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: password_reset_tokens
DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: personal_access_tokens
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `personal_access_tokens` VALUES ('3', 'App\\Models\\User', '2', 'api-token', 'b20bca9dab92405433c65515d630268d71e899970ffaa49d045e9bcdb972997a', '[\"*\"]', '2026-02-19 09:58:44', NULL, '2026-02-18 17:40:02', '2026-02-19 09:58:44');
INSERT INTO `personal_access_tokens` VALUES ('25', 'App\\Models\\User', '3', 'api-token', '9014f10a4707563a6957870d1ae1fbb04983e2b78b528c039173106f6a614711', '[\"*\"]', '2026-03-01 21:05:28', NULL, '2026-03-01 20:39:17', '2026-03-01 21:05:28');
INSERT INTO `personal_access_tokens` VALUES ('26', 'App\\Models\\User', '1', 'api-token', 'ab7011f05577679b3b954f77368ab6d5a5ccec6bb68b6819348a13f27f69554c', '[\"*\"]', '2026-03-02 20:01:46', NULL, '2026-03-02 20:00:25', '2026-03-02 20:01:46');

-- Table: prescription_items
DROP TABLE IF EXISTS `prescription_items`;
CREATE TABLE `prescription_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prescription_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `prescribed_quantity` int(11) NOT NULL,
  `dispensed_quantity` int(11) NOT NULL DEFAULT 0,
  `dosage` varchar(255) DEFAULT NULL,
  `frequency` varchar(255) DEFAULT NULL,
  `duration_days` int(11) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `is_controlled_substance` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prescription_items_prescription_id_foreign` (`prescription_id`),
  KEY `prescription_items_product_id_foreign` (`product_id`),
  CONSTRAINT `prescription_items_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescription_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: prescriptions
DROP TABLE IF EXISTS `prescriptions`;
CREATE TABLE `prescriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prescription_number` varchar(255) NOT NULL,
  `patient_name` varchar(255) NOT NULL,
  `patient_phone` varchar(255) DEFAULT NULL,
  `patient_address` text DEFAULT NULL,
  `patient_dob` date DEFAULT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `doctor_license` varchar(255) DEFAULT NULL,
  `hospital` varchar(255) DEFAULT NULL,
  `prescription_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `status` enum('pending','dispensed','partially_dispensed','expired','cancelled') NOT NULL DEFAULT 'pending',
  `dispensed_by` bigint(20) unsigned DEFAULT NULL,
  `dispensed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prescriptions_prescription_number_unique` (`prescription_number`),
  KEY `prescriptions_dispensed_by_foreign` (`dispensed_by`),
  KEY `prescriptions_prescription_number_index` (`prescription_number`),
  KEY `prescriptions_patient_name_index` (`patient_name`),
  KEY `prescriptions_status_index` (`status`),
  CONSTRAINT `prescriptions_dispensed_by_foreign` FOREIGN KEY (`dispensed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: product_batches
DROP TABLE IF EXISTS `product_batches`;
CREATE TABLE `product_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `batch_number` varchar(255) NOT NULL,
  `manufacturing_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity_received` int(11) NOT NULL,
  `quantity_remaining` int(11) NOT NULL,
  `cost_price` decimal(15,2) NOT NULL,
  `selling_price` decimal(15,2) NOT NULL,
  `purchase_order_id` bigint(20) unsigned DEFAULT NULL,
  `purchase_order_item_id` bigint(20) unsigned DEFAULT NULL,
  `supplier_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('active','expired','recalled','damaged') NOT NULL DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_batches_batch_number_unique` (`batch_number`),
  KEY `product_batches_purchase_order_id_foreign` (`purchase_order_id`),
  KEY `product_batches_supplier_id_foreign` (`supplier_id`),
  KEY `product_batches_batch_number_index` (`batch_number`),
  KEY `product_batches_expiry_date_index` (`expiry_date`),
  KEY `product_batches_product_id_status_index` (`product_id`,`status`),
  KEY `product_batches_purchase_order_item_id_index` (`purchase_order_item_id`),
  CONSTRAINT `product_batches_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_batches_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_batches_purchase_order_item_id_foreign` FOREIGN KEY (`purchase_order_item_id`) REFERENCES `purchase_order_items` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_batches_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_batches` VALUES ('1', '10', 'PO-PO-2026-0020-10', '2024-09-01', '2028-09-01', '0', '0', '5000.00', '7500.00', '27', NULL, '2', 'active', NULL, '2026-03-01 16:10:28', '2026-03-01 16:10:28', NULL);
INSERT INTO `product_batches` VALUES ('6', '10', 'PO-PO-2026-0021-10', '2024-09-01', '2028-09-01', '5', '5', '5000.00', '7500.00', '28', NULL, '2', 'active', NULL, '2026-03-01 16:24:14', '2026-03-01 16:29:06', NULL);
INSERT INTO `product_batches` VALUES ('8', '11', 'PO-PO-2026-0022-11', '2026-03-01', '2026-06-01', '1', '1', '1500.00', '1700.00', '29', NULL, '3', 'active', NULL, '2026-03-01 19:29:27', '2026-03-01 19:31:14', NULL);

-- Table: product_price_history
DROP TABLE IF EXISTS `product_price_history`;
CREATE TABLE `product_price_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `old_price` decimal(10,2) DEFAULT NULL,
  `new_price` decimal(10,2) NOT NULL,
  `price_change` decimal(10,2) DEFAULT NULL,
  `percentage_change` decimal(8,2) DEFAULT NULL,
  `change_type` enum('purchase','manual','sale') NOT NULL DEFAULT 'manual',
  `supplier_name` varchar(255) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `changed_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_price_history_changed_by_foreign` (`changed_by`),
  KEY `product_price_history_product_id_changed_at_index` (`product_id`,`changed_at`),
  KEY `product_price_history_change_type_index` (`change_type`),
  CONSTRAINT `product_price_history_changed_by_foreign` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_price_history_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `product_price_history` VALUES ('1', '8', '50000.00', '65000.00', '15000.00', '30.00', 'purchase', 'Golden Fabrics Lagos', 'PO-2026-0017', '1', 'Price increased by ₦15,000.00 (30.00%)', '2026-02-24 15:01:54', '2026-02-24 15:01:54', '2026-02-24 15:01:54');
INSERT INTO `product_price_history` VALUES ('2', '8', '65000.00', '60000.00', '-5000.00', '-7.69', 'purchase', 'Golden Fabrics Lagos', 'PO-2026-0018', '1', 'Price decreased by ₦5,000.00 (7.69%)', '2026-02-24 15:32:39', '2026-02-24 15:32:39', '2026-02-24 15:32:39');
INSERT INTO `product_price_history` VALUES ('3', '5', '2000.00', '1950.00', '-50.00', '-2.50', 'purchase', 'Global Foods Distribution', 'PO-2026-0019', '1', 'Price decreased by ₦50.00 (2.50%)', '2026-02-27 22:54:03', '2026-02-27 22:54:03', '2026-02-27 22:54:03');
INSERT INTO `product_price_history` VALUES ('4', '10', NULL, '5000.00', '5000.00', '0.00', 'purchase', 'Global Foods Distribution', 'PO-2026-0021', '1', 'Price increased by ₦5,000.00 (0.00%)', '2026-03-01 16:29:06', '2026-03-01 16:29:06', '2026-03-01 16:29:06');
INSERT INTO `product_price_history` VALUES ('5', '11', NULL, '1500.00', '1500.00', '0.00', 'purchase', 'NDA Watu Store', 'PO-2026-0022', '1', 'Price increased by ₦1,500.00 (0.00%)', '2026-03-01 19:31:14', '2026-03-01 19:31:14', '2026-03-01 19:31:14');

-- Table: product_reviews
DROP TABLE IF EXISTS `product_reviews`;
CREATE TABLE `product_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `rating` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `review` text DEFAULT NULL,
  `is_verified_purchase` tinyint(1) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_reviews_customer_id_foreign` (`customer_id`),
  KEY `product_reviews_order_id_foreign` (`order_id`),
  KEY `product_reviews_product_id_index` (`product_id`),
  KEY `product_reviews_rating_index` (`rating`),
  CONSTRAINT `product_reviews_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_reviews_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: products
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `track_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `track_batch` tinyint(1) NOT NULL DEFAULT 0,
  `track_serial` tinyint(1) NOT NULL DEFAULT 0,
  `is_controlled_substance` tinyint(1) NOT NULL DEFAULT 0,
  `controlled_substance_schedule` enum('I','II','III','IV','V') DEFAULT NULL,
  `requires_prescription` tinyint(1) NOT NULL DEFAULT 0,
  `serial_number` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost_price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `last_purchase_price` decimal(12,2) DEFAULT NULL,
  `stock_quantity` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 10,
  `low_stock_threshold` int(11) NOT NULL DEFAULT 10,
  `expiry_date` date DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `reorder_point` int(11) NOT NULL DEFAULT 10,
  `auto_reorder_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `auto_reorder_quantity` int(11) DEFAULT NULL,
  `max_stock_level` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `department_id` bigint(20) unsigned NOT NULL,
  `warehouse_location` varchar(255) DEFAULT NULL,
  `shelf_position` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  UNIQUE KEY `products_sku_unique` (`sku`),
  UNIQUE KEY `products_barcode_unique` (`barcode`),
  KEY `products_expiry_date_index` (`expiry_date`),
  KEY `products_cost_price_index` (`cost_price`),
  KEY `products_barcode_index` (`barcode`),
  KEY `products_name_index` (`name`),
  KEY `products_is_active_index` (`is_active`),
  KEY `products_is_featured_index` (`is_featured`),
  KEY `products_stock_quantity_index` (`stock_quantity`),
  KEY `products_department_id_is_active_index` (`department_id`,`is_active`),
  KEY `products_is_active_stock_quantity_index` (`is_active`,`stock_quantity`),
  CONSTRAINT `products_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` VALUES ('1', 'Paracetamol 500mg (Pack of 100)', 'paracetamol-500mg', 'PHM-PAR-500', NULL, '0', '0', '0', '0', NULL, '0', NULL, 'Pain relief and fever reducer', '2500.00', '1800.00', '1800.00', '148', '10', '20', NULL, NULL, '30', '0', NULL, '300', 'products/DLcIkEMx4m8N4i1tCrACGnRFKR23flH7TLOhQUMU.jpg', '1', NULL, NULL, '1', '0', '2026-02-18 17:35:08', '2026-02-23 20:25:41', NULL);
INSERT INTO `products` VALUES ('2', 'Golden Penny Semovita 2kg', 'golden-penny-semovita-2kg', 'SS-GP-SEM-2', NULL, '0', '0', '0', '0', NULL, '0', NULL, 'Premium quality semovita', '3200.00', '2016.67', '1800.00', '150', '10', '15', NULL, NULL, '20', '0', NULL, '200', 'products/AYck819zKrAnMvw6fRvzO5Z044Q5ten6TaqLaXse.jpg', '2', NULL, NULL, '1', '0', '2026-02-18 17:35:08', '2026-02-22 20:24:50', NULL);
INSERT INTO `products` VALUES ('3', 'Ducros Dried Thyme 10g', 'ducros-dried-thyme-10g', NULL, '3275920039158', '0', '0', '0', '0', NULL, '0', NULL, 'Thyme', '800.00', '121.21', '800.00', '33', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/Y6mW2O7USTNnPN0Q8Qknf4CsOZkCKIv7DZGbdJiH.jpg', '2', NULL, NULL, '1', '0', '2026-02-19 16:59:12', '2026-02-19 20:18:58', NULL);
INSERT INTO `products` VALUES ('4', '100 inch Smart Android TV', '100-inch-smart-android-tv', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '180000.00', '1350000.00', '1800000.00', '2', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/KWrpKqF8PB2Reet6HWXdl4YnRzFNoJoE2VBMQhSM.jpg', '3', NULL, NULL, '1', '0', '2026-02-19 18:30:34', '2026-02-20 20:27:00', NULL);
INSERT INTO `products` VALUES ('5', 'Oba Macaroni', 'oba-macaroni', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '2000.00', '864.20', '1950.00', '317', '10', '10', NULL, NULL, '10', '0', NULL, NULL, NULL, '2', NULL, NULL, '1', '0', '2026-02-20 20:47:57', '2026-02-27 22:54:03', NULL);
INSERT INTO `products` VALUES ('6', 'Electric Jug Kettle', 'electric-jug-kettle', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '75000.00', '65000.00', '65000.00', '5', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/bdGnZUaNGYYAbghZabOfqB1bAwEcW0zAxab6vrIy.jpg', '3', NULL, NULL, '1', '0', '2026-02-22 20:43:01', '2026-02-23 14:47:10', NULL);
INSERT INTO `products` VALUES ('7', 'Indomie Noodles (Carton)', 'indomie-noodles-carton', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '14000.00', '13500.00', '13500.00', '50', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/BlgWeLjQAsBIqgeCpdnp1nSXAyg4ROGWbzpVXhAT.webp', '2', NULL, NULL, '1', '0', '2026-02-22 20:44:25', '2026-02-22 20:46:48', NULL);
INSERT INTO `products` VALUES ('8', 'Lagos Lace Fabric', 'lagos-lace-fabric', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '85000.00', '52083.34', '60000.00', '12', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/qGdKPcAnGlZxoHkOfOdh46VQpiucItKEhQ96uEYZ.jpg', '4', NULL, NULL, '1', '0', '2026-02-23 15:36:48', '2026-02-24 15:32:39', NULL);
INSERT INTO `products` VALUES ('9', 'Baby Feeding Bottles Set', 'baby-feeding-bottles-set', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '55000.00', '48000.00', '48000.00', '4', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/5zbl22rpSF5YqbA4I7egLFrCfwYy1O51qwS6WpVu.jpg', '5', NULL, NULL, '1', '0', '2026-02-23 17:43:55', '2026-02-23 20:17:39', NULL);
INSERT INTO `products` VALUES ('10', 'Samira Green Tea', 'samira-green-tea', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '7500.00', '5000.00', '5000.00', '5', '10', '10', NULL, NULL, '10', '0', NULL, NULL, 'products/MCQ29Vp3HtMwyY62f99NCTabIOLyTP289yI1JUT0.webp', '2', NULL, NULL, '1', '0', '2026-02-28 20:14:31', '2026-03-01 16:29:06', NULL);
INSERT INTO `products` VALUES ('11', 'Golden Penny Semovita 1kg', 'golden-penny-semovita-1kg', NULL, NULL, '0', '0', '0', '0', NULL, '0', NULL, NULL, '1700.00', '1500.00', '1500.00', '1', '10', '10', NULL, NULL, '10', '0', NULL, NULL, NULL, '2', NULL, NULL, '1', '0', '2026-03-01 14:28:25', '2026-03-01 19:31:14', NULL);

-- Table: purchase_order_items
DROP TABLE IF EXISTS `purchase_order_items`;
CREATE TABLE `purchase_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity_ordered` int(11) NOT NULL,
  `quantity_received` int(11) NOT NULL DEFAULT 0,
  `unit_type` enum('piece','carton','box','pack','dozen','kg','liter','meter') NOT NULL DEFAULT 'piece',
  `unit_cost` decimal(12,2) NOT NULL,
  `vat_rate` decimal(5,2) NOT NULL DEFAULT 7.50,
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `manufacturing_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_items_purchase_order_id_index` (`purchase_order_id`),
  KEY `purchase_order_items_product_id_index` (`product_id`),
  KEY `purchase_order_items_purchase_order_id_product_id_index` (`purchase_order_id`,`product_id`),
  KEY `purchase_order_items_batch_number_index` (`batch_number`),
  KEY `purchase_order_items_expiry_date_index` (`expiry_date`),
  CONSTRAINT `purchase_order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `purchase_order_items_purchase_order_id_foreign` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_order_items` VALUES ('1', '1', '3', '14', '14', 'piece', '0.00', '7.50', '0.00', '0.00', NULL, NULL, NULL, NULL, '2026-02-19 17:43:01', '2026-02-19 19:39:06');
INSERT INTO `purchase_order_items` VALUES ('2', '2', '2', '5', '5', 'piece', '1800.00', '7.50', '0.00', '9000.00', NULL, NULL, NULL, NULL, '2026-02-19 17:59:50', '2026-02-19 19:41:50');
INSERT INTO `purchase_order_items` VALUES ('3', '3', '4', '1', '1', 'piece', '1800000.00', '7.50', '0.00', '1800000.00', NULL, NULL, NULL, NULL, '2026-02-19 18:31:35', '2026-02-19 19:28:51');
INSERT INTO `purchase_order_items` VALUES ('4', '4', '3', '5', '5', 'piece', '800.00', '7.50', '0.00', '4000.00', NULL, NULL, NULL, NULL, '2026-02-19 19:31:30', '2026-02-19 19:40:20');
INSERT INTO `purchase_order_items` VALUES ('5', '5', '2', '100', '100', 'piece', '1800.00', '7.50', '0.00', '180000.00', NULL, NULL, NULL, NULL, '2026-02-20 14:57:05', '2026-02-20 14:59:04');
INSERT INTO `purchase_order_items` VALUES ('6', '6', '4', '1', '1', 'piece', '1800000.00', '7.50', '0.00', '1800000.00', NULL, NULL, NULL, NULL, '2026-02-20 20:25:00', '2026-02-20 20:27:00');
INSERT INTO `purchase_order_items` VALUES ('7', '7', '2', '20', '20', 'piece', '1800.00', '7.50', '0.00', '36000.00', NULL, NULL, NULL, NULL, '2026-02-20 20:29:46', '2026-02-22 20:24:50');
INSERT INTO `purchase_order_items` VALUES ('8', '8', '5', '100', '100', 'piece', '0.00', '7.50', '0.00', '0.00', NULL, NULL, NULL, NULL, '2026-02-20 20:50:51', '2026-02-22 20:24:12');
INSERT INTO `purchase_order_items` VALUES ('9', '9', '5', '100', '100', 'piece', '700.00', '7.50', '0.00', '70000.00', NULL, NULL, NULL, NULL, '2026-02-20 20:52:54', '2026-02-22 20:09:58');
INSERT INTO `purchase_order_items` VALUES ('10', '10', '5', '100', '100', 'piece', '2000.00', '7.50', '0.00', '200000.00', NULL, NULL, NULL, NULL, '2026-02-20 21:33:56', '2026-02-22 20:05:32');
INSERT INTO `purchase_order_items` VALUES ('11', '11', '7', '50', '50', 'piece', '13500.00', '0.00', '0.00', '675000.00', NULL, NULL, NULL, NULL, '2026-02-22 20:45:30', '2026-02-22 20:46:48');
INSERT INTO `purchase_order_items` VALUES ('12', '12', '5', '1', '0', 'piece', '200.00', '0.00', '0.00', '200.00', NULL, NULL, NULL, NULL, '2026-02-22 21:04:43', '2026-02-22 21:04:43');
INSERT INTO `purchase_order_items` VALUES ('13', '13', '5', '1', '1', 'piece', '2000.00', '0.00', '0.00', '2000.00', NULL, NULL, NULL, NULL, '2026-02-23 14:08:50', '2026-02-23 14:32:07');
INSERT INTO `purchase_order_items` VALUES ('14', '14', '6', '5', '5', 'piece', '65000.00', '0.00', '0.00', '325000.00', NULL, NULL, NULL, NULL, '2026-02-23 14:34:51', '2026-02-23 14:47:10');
INSERT INTO `purchase_order_items` VALUES ('15', '15', '8', '10', '10', 'piece', '50000.00', '0.00', '0.00', '500000.00', NULL, NULL, NULL, NULL, '2026-02-23 15:45:22', '2026-02-23 15:46:19');
INSERT INTO `purchase_order_items` VALUES ('16', '16', '9', '5', '5', 'piece', '48000.00', '0.00', '0.00', '240000.00', NULL, NULL, NULL, NULL, '2026-02-23 18:31:17', '2026-02-23 18:32:19');
INSERT INTO `purchase_order_items` VALUES ('17', '17', '8', '1', '1', 'piece', '65000.00', '0.00', '0.00', '65000.00', NULL, NULL, NULL, NULL, '2026-02-24 15:00:50', '2026-02-24 15:01:54');
INSERT INTO `purchase_order_items` VALUES ('18', '18', '8', '1', '1', 'piece', '60000.00', '0.00', '0.00', '60000.00', NULL, NULL, NULL, NULL, '2026-02-24 15:31:27', '2026-02-24 15:32:39');
INSERT INTO `purchase_order_items` VALUES ('19', '23', '5', '1', '1', 'piece', '1950.00', '0.00', '0.00', '1950.00', NULL, NULL, NULL, NULL, '2026-02-27 22:53:19', '2026-02-27 22:54:03');
INSERT INTO `purchase_order_items` VALUES ('23', '27', '10', '5', '0', 'piece', '5000.00', '0.00', '0.00', '25000.00', NULL, NULL, NULL, NULL, '2026-03-01 16:10:28', '2026-03-01 16:10:28');
INSERT INTO `purchase_order_items` VALUES ('24', '27', '11', '5', '0', 'piece', '1500.00', '0.00', '0.00', '7500.00', NULL, NULL, NULL, NULL, '2026-03-01 16:10:28', '2026-03-01 16:10:28');
INSERT INTO `purchase_order_items` VALUES ('25', '28', '10', '5', '5', 'piece', '5000.00', '0.00', '0.00', '25000.00', NULL, NULL, NULL, NULL, '2026-03-01 16:24:14', '2026-03-01 16:29:06');
INSERT INTO `purchase_order_items` VALUES ('26', '29', '11', '1', '1', 'piece', '1500.00', '0.00', '0.00', '1500.00', NULL, NULL, NULL, NULL, '2026-03-01 19:29:27', '2026-03-01 19:31:14');

-- Table: purchase_orders
DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE `purchase_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `po_number` varchar(255) NOT NULL,
  `supplier_id` bigint(20) unsigned NOT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `received_by` bigint(20) unsigned DEFAULT NULL,
  `status` enum('draft','pending','approved','rejected','ordered','partially_received','received','cancelled') NOT NULL DEFAULT 'draft',
  `order_date` date NOT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `actual_delivery_date` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `vat_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `shipping_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('unpaid','partially_paid','paid') NOT NULL DEFAULT 'unpaid',
  `payment_method` enum('cash','bank_transfer','cheque','card','credit') NOT NULL DEFAULT 'credit',
  `payment_due_date` date DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchase_orders_po_number_unique` (`po_number`),
  KEY `purchase_orders_created_by_foreign` (`created_by`),
  KEY `purchase_orders_approved_by_foreign` (`approved_by`),
  KEY `purchase_orders_received_by_foreign` (`received_by`),
  KEY `purchase_orders_po_number_index` (`po_number`),
  KEY `purchase_orders_status_index` (`status`),
  KEY `purchase_orders_payment_status_index` (`payment_status`),
  KEY `purchase_orders_order_date_index` (`order_date`),
  KEY `purchase_orders_supplier_id_status_index` (`supplier_id`,`status`),
  KEY `purchase_orders_department_id_status_index` (`department_id`,`status`),
  KEY `purchase_orders_expected_delivery_date_index` (`expected_delivery_date`),
  CONSTRAINT `purchase_orders_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `purchase_orders_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `purchase_orders_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `purchase_orders_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`),
  CONSTRAINT `purchase_orders_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_orders` VALUES ('1', 'PO-2026-0001', '4', NULL, '1', '1', '1', 'received', '2026-02-19', '2026-02-19', '2026-02-19', '0.00', '0.00', '0.00', '0.00', '0.00', 'paid', 'cash', NULL, '2026-02-19', '11200.00', NULL, NULL, '2026-02-19 19:37:56', '2026-02-19 19:39:06', NULL, '2026-02-19 17:43:01', '2026-02-19 19:39:06');
INSERT INTO `purchase_orders` VALUES ('2', 'PO-2026-0002', '3', NULL, '1', '1', '1', 'received', '2026-02-19', '2026-02-19', '2026-02-19', '9000.00', '675.00', '0.00', '0.00', '9000.00', 'paid', 'bank_transfer', NULL, '2026-02-19', '9000.00', NULL, NULL, '2026-02-19 19:41:22', '2026-02-19 19:41:50', NULL, '2026-02-19 17:59:50', '2026-02-19 19:41:50');
INSERT INTO `purchase_orders` VALUES ('3', 'PO-2026-0003', '3', NULL, '1', '1', '1', 'received', '2026-02-19', '2026-02-19', '2026-02-19', '1800000.00', '135000.00', '0.00', '0.00', '1800000.00', 'paid', 'bank_transfer', NULL, '2026-02-19', '1800000.00', NULL, NULL, '2026-02-19 19:27:01', '2026-02-19 19:28:51', NULL, '2026-02-19 18:31:35', '2026-02-19 19:28:51');
INSERT INTO `purchase_orders` VALUES ('4', 'PO-2026-0004', '2', '2', '3', '1', '1', 'received', '2026-02-19', '2026-02-19', '2026-02-19', '4000.00', '300.00', '0.00', '0.00', '4000.00', 'paid', 'bank_transfer', NULL, '2026-02-19', '4000.00', NULL, NULL, '2026-02-19 19:39:44', '2026-02-19 19:40:20', NULL, '2026-02-19 19:31:30', '2026-02-19 19:40:20');
INSERT INTO `purchase_orders` VALUES ('5', 'PO-2026-0005', '4', NULL, '1', '1', '1', 'received', '2026-02-20', '2026-02-20', '2026-02-20', '180000.00', '13500.00', '0.00', '0.00', '180000.00', 'paid', 'bank_transfer', NULL, '2026-02-20', '180000.00', NULL, NULL, '2026-02-20 14:57:54', '2026-02-20 14:59:04', NULL, '2026-02-20 14:57:05', '2026-02-20 14:59:04');
INSERT INTO `purchase_orders` VALUES ('6', 'PO-2026-0006', '3', NULL, '1', '1', '1', 'received', '2026-02-20', NULL, '2026-02-20', '1800000.00', '135000.00', '0.00', '0.00', '1800000.00', 'paid', 'bank_transfer', NULL, '2026-02-20', '1800000.00', NULL, NULL, '2026-02-20 20:25:56', '2026-02-20 20:27:00', NULL, '2026-02-20 20:25:00', '2026-02-20 20:27:00');
INSERT INTO `purchase_orders` VALUES ('7', 'PO-2026-0007', '2', '2', '3', '1', '1', 'received', '2026-02-20', NULL, '2026-02-22', '36000.00', '2700.00', '0.00', '0.00', '36000.00', 'paid', 'bank_transfer', NULL, '2026-02-22', '36000.00', NULL, NULL, '2026-02-20 20:31:24', '2026-02-22 20:24:50', NULL, '2026-02-20 20:29:46', '2026-02-22 20:24:50');
INSERT INTO `purchase_orders` VALUES ('8', 'PO-2026-0008', '2', '2', '3', '1', '1', 'received', '2026-02-20', '2026-02-20', '2026-02-22', '0.00', '0.00', '0.00', '0.00', '0.00', 'paid', 'bank_transfer', NULL, '2026-02-22', '200000.00', NULL, NULL, '2026-02-20 20:51:33', '2026-02-22 20:24:12', NULL, '2026-02-20 20:50:51', '2026-02-22 20:24:12');
INSERT INTO `purchase_orders` VALUES ('9', 'PO-2026-0009', '2', '2', '3', '1', '1', 'received', '2026-02-20', '2026-02-20', '2026-02-22', '70000.00', '5250.00', '0.00', '0.00', '70000.00', 'paid', 'bank_transfer', NULL, '2026-02-22', '70000.00', NULL, NULL, '2026-02-20 20:53:30', '2026-02-22 20:09:58', NULL, '2026-02-20 20:52:54', '2026-02-22 20:09:58');
INSERT INTO `purchase_orders` VALUES ('10', 'PO-2026-0010', '4', NULL, '1', '1', '1', 'received', '2026-02-20', '2026-02-20', '2026-02-22', '200000.00', '15000.00', '0.00', '0.00', '200000.00', 'paid', 'bank_transfer', NULL, '2026-02-22', '200000.00', NULL, NULL, '2026-02-20 21:37:59', '2026-02-22 20:05:32', NULL, '2026-02-20 21:33:56', '2026-02-22 20:05:32');
INSERT INTO `purchase_orders` VALUES ('11', 'PO-2026-0011', '2', '2', '3', '1', '1', 'received', '2026-02-22', '2026-02-22', '2026-02-22', '675000.00', '0.00', '0.00', '0.00', '675000.00', 'paid', 'bank_transfer', NULL, '2026-02-22', '675000.00', NULL, NULL, '2026-02-22 20:45:58', '2026-02-22 20:46:48', NULL, '2026-02-22 20:45:30', '2026-02-22 20:46:48');
INSERT INTO `purchase_orders` VALUES ('12', 'PO-2026-0012', '2', '2', '3', NULL, NULL, 'cancelled', '2026-02-22', NULL, NULL, '200.00', '0.00', '0.00', '0.00', '200.00', 'unpaid', 'credit', NULL, NULL, '0.00', 'CANCELLED by Master Admin on 2026-02-22 21:05:10
Reason: We have it in stock', NULL, NULL, NULL, NULL, '2026-02-22 21:04:43', '2026-02-22 21:05:10');
INSERT INTO `purchase_orders` VALUES ('13', 'PO-2026-0013', '2', '2', '3', '1', '1', 'received', '2026-02-23', '2026-02-23', '2026-02-23', '2000.00', '0.00', '0.00', '0.00', '2000.00', 'paid', 'bank_transfer', NULL, '2026-02-23', '2000.00', NULL, NULL, '2026-02-23 14:23:48', '2026-02-23 14:32:07', NULL, '2026-02-23 14:08:50', '2026-02-23 14:32:30');
INSERT INTO `purchase_orders` VALUES ('14', 'PO-2026-0014', '3', NULL, '1', '1', '1', 'received', '2026-02-23', '2026-02-23', '2026-02-23', '325000.00', '0.00', '0.00', '0.00', '325000.00', 'paid', 'bank_transfer', '2026-03-25', '2026-02-23', '325000.00', NULL, NULL, '2026-02-23 14:35:08', '2026-02-23 14:47:10', NULL, '2026-02-23 14:34:51', '2026-02-23 14:50:38');
INSERT INTO `purchase_orders` VALUES ('15', 'PO-2026-0015', '5', NULL, '1', '1', '1', 'received', '2026-02-23', '2026-02-23', '2026-02-23', '500000.00', '0.00', '0.00', '0.00', '500000.00', 'paid', 'bank_transfer', '2026-03-25', '2026-02-23', '500000.00', NULL, NULL, '2026-02-23 15:45:41', '2026-02-23 15:46:19', NULL, '2026-02-23 15:45:22', '2026-02-23 15:47:27');
INSERT INTO `purchase_orders` VALUES ('16', 'PO-2026-0016', '6', NULL, '1', '1', '1', 'received', '2026-02-23', '2026-02-23', '2026-02-23', '240000.00', '0.00', '0.00', '0.00', '240000.00', 'paid', 'bank_transfer', NULL, '2026-02-23', '240000.00', NULL, NULL, '2026-02-23 18:31:30', '2026-02-23 18:32:19', NULL, '2026-02-23 18:31:17', '2026-02-23 18:32:19');
INSERT INTO `purchase_orders` VALUES ('17', 'PO-2026-0017', '5', NULL, '1', '1', '1', 'received', '2026-02-24', '2026-02-24', '2026-02-24', '65000.00', '0.00', '0.00', '0.00', '65000.00', 'paid', 'bank_transfer', '2026-03-26', '2026-02-24', '65000.00', NULL, NULL, '2026-02-24 15:01:05', '2026-02-24 15:01:54', NULL, '2026-02-24 15:00:50', '2026-02-24 15:03:06');
INSERT INTO `purchase_orders` VALUES ('18', 'PO-2026-0018', '5', NULL, '1', '1', '1', 'received', '2026-02-24', '2026-02-24', '2026-02-24', '60000.00', '0.00', '0.00', '0.00', '60000.00', 'paid', 'bank_transfer', NULL, '2026-02-24', '60000.00', NULL, NULL, '2026-02-24 15:31:54', '2026-02-24 15:32:39', NULL, '2026-02-24 15:31:27', '2026-02-24 15:32:39');
INSERT INTO `purchase_orders` VALUES ('23', 'PO-2026-0019', '2', NULL, '1', '1', '1', 'received', '2026-02-27', '2026-02-27', '2026-02-27', '1950.00', '0.00', '0.00', '0.00', '1950.00', 'paid', 'bank_transfer', NULL, '2026-02-27', '1950.00', NULL, NULL, '2026-02-27 22:53:34', '2026-02-27 22:54:03', NULL, '2026-02-27 22:53:19', '2026-02-27 22:54:03');
INSERT INTO `purchase_orders` VALUES ('27', 'PO-2026-0020', '2', '2', '3', '1', NULL, 'cancelled', '2026-03-01', '2026-03-01', NULL, '32500.00', '0.00', '0.00', '0.00', '32500.00', 'paid', 'bank_transfer', NULL, '2026-03-01', '32500.00', 'CANCELLED by Master Admin on 2026-03-01 16:21:56
Reason: It failed to recieve goods', NULL, '2026-03-01 16:11:16', NULL, NULL, '2026-03-01 16:10:28', '2026-03-01 16:21:56');
INSERT INTO `purchase_orders` VALUES ('28', 'PO-2026-0021', '2', '2', '3', '1', '1', 'received', '2026-03-01', '2026-03-01', '2026-03-01', '25000.00', '0.00', '0.00', '0.00', '25000.00', 'paid', 'bank_transfer', NULL, '2026-03-01', '25000.00', NULL, NULL, '2026-03-01 16:24:57', '2026-03-01 16:29:06', NULL, '2026-03-01 16:24:14', '2026-03-01 16:29:06');
INSERT INTO `purchase_orders` VALUES ('29', 'PO-2026-0022', '3', '2', '3', '1', '1', 'received', '2026-03-01', '2026-03-01', '2026-03-01', '1500.00', '0.00', '0.00', '0.00', '1500.00', 'paid', 'bank_transfer', NULL, '2026-03-01', '1500.00', NULL, NULL, '2026-03-01 19:30:06', '2026-03-01 19:31:14', NULL, '2026-03-01 19:29:27', '2026-03-01 19:31:14');

-- Table: sale_items
DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE `sale_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `unit_cost` decimal(12,2) NOT NULL,
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(15,2) NOT NULL,
  `line_cost` decimal(15,2) NOT NULL,
  `line_profit` decimal(15,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_items_sale_id_index` (`sale_id`),
  KEY `sale_items_product_id_index` (`product_id`),
  KEY `sale_items_sale_id_product_id_index` (`sale_id`,`product_id`),
  CONSTRAINT `sale_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sale_items` VALUES ('1', '1', '1', '2', '2500.00', '1800.00', '0.00', '5000.00', '3600.00', '1400.00', NULL, '2026-02-19 14:17:47', '2026-02-19 14:17:47');
INSERT INTO `sale_items` VALUES ('2', '1', '2', '5', '3200.00', '2400.00', '0.00', '16000.00', '12000.00', '4000.00', NULL, '2026-02-19 14:17:47', '2026-02-19 14:17:47');
INSERT INTO `sale_items` VALUES ('3', '2', '3', '1', '800.00', '0.00', '0.00', '800.00', '0.00', '800.00', NULL, '2026-02-19 18:22:44', '2026-02-19 18:22:44');
INSERT INTO `sale_items` VALUES ('4', '3', '4', '1', '2000000.00', '900000.00', '0.00', '2000000.00', '900000.00', '1100000.00', NULL, '2026-02-19 19:43:52', '2026-02-19 19:43:52');
INSERT INTO `sale_items` VALUES ('5', '4', '2', '50', '3200.00', '2050.00', '0.00', '160000.00', '102500.00', '57500.00', NULL, '2026-02-20 20:21:59', '2026-02-20 20:21:59');
INSERT INTO `sale_items` VALUES ('6', '5', '9', '1', '55000.00', '48000.00', '0.00', '55000.00', '48000.00', '7000.00', NULL, '2026-02-23 20:17:39', '2026-02-23 20:17:39');

-- Table: sales
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_number` varchar(255) NOT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `cashier_id` bigint(20) unsigned NOT NULL,
  `sale_type` enum('cash','credit','online','pos') NOT NULL DEFAULT 'cash',
  `payment_status` enum('unpaid','partially_paid','paid') NOT NULL DEFAULT 'paid',
  `subtotal` decimal(15,2) NOT NULL,
  `vat_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(15,2) NOT NULL,
  `amount_paid` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount_due` decimal(15,2) NOT NULL DEFAULT 0.00,
  `cost_of_goods_sold` decimal(15,2) NOT NULL DEFAULT 0.00,
  `gross_profit` decimal(15,2) NOT NULL DEFAULT 0.00,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_sale_number_unique` (`sale_number`),
  KEY `sales_sale_number_index` (`sale_number`),
  KEY `sales_sale_type_index` (`sale_type`),
  KEY `sales_payment_status_index` (`payment_status`),
  KEY `sales_sale_date_index` (`sale_date`),
  KEY `sales_department_id_sale_date_index` (`department_id`,`sale_date`),
  KEY `sales_cashier_id_sale_date_index` (`cashier_id`,`sale_date`),
  KEY `sales_total_amount_index` (`total_amount`),
  CONSTRAINT `sales_cashier_id_foreign` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`),
  CONSTRAINT `sales_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sales` VALUES ('1', 'SALE-2026-0001', NULL, '1', 'cash', 'paid', '21000.00', '1575.00', '0.00', '21000.00', '21000.00', '0.00', '15600.00', '5400.00', NULL, NULL, NULL, '2026-02-19 00:00:00', NULL, '2026-02-19 14:17:47', '2026-02-19 14:17:47');
INSERT INTO `sales` VALUES ('2', 'SALE-2026-0002', NULL, '1', 'online', 'paid', '800.00', '60.00', '0.00', '800.00', '800.00', '0.00', '0.00', '800.00', NULL, NULL, NULL, '2026-02-19 00:00:00', NULL, '2026-02-19 18:22:44', '2026-02-19 18:22:44');
INSERT INTO `sales` VALUES ('3', 'SALE-2026-0003', NULL, '1', 'online', 'paid', '2000000.00', '150000.00', '0.00', '2000000.00', '2000000.00', '0.00', '900000.00', '1100000.00', NULL, NULL, NULL, '2026-02-19 00:00:00', NULL, '2026-02-19 19:43:52', '2026-02-19 19:43:52');
INSERT INTO `sales` VALUES ('4', 'SALE-2026-0004', NULL, '1', 'online', 'paid', '160000.00', '12000.00', '0.00', '160000.00', '160000.00', '0.00', '102500.00', '57500.00', NULL, NULL, NULL, '2026-02-20 00:00:00', NULL, '2026-02-20 20:21:59', '2026-02-20 20:21:59');
INSERT INTO `sales` VALUES ('5', 'SALE-2026-0005', NULL, '1', 'online', 'paid', '55000.00', '4125.00', '0.00', '55000.00', '55000.00', '0.00', '48000.00', '7000.00', NULL, NULL, NULL, '2026-02-23 00:00:00', NULL, '2026-02-23 20:17:39', '2026-02-23 20:17:39');

-- Table: security_settings
DROP TABLE IF EXISTS `security_settings`;
CREATE TABLE `security_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ip_whitelist_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `two_fa_required` tinyint(1) NOT NULL DEFAULT 0,
  `password_min_length` int(11) NOT NULL DEFAULT 8,
  `password_require_uppercase` tinyint(1) NOT NULL DEFAULT 1,
  `password_require_numbers` tinyint(1) NOT NULL DEFAULT 1,
  `password_require_symbols` tinyint(1) NOT NULL DEFAULT 0,
  `password_expiry_days` int(11) NOT NULL DEFAULT 90,
  `max_login_attempts` int(11) NOT NULL DEFAULT 5,
  `lockout_duration_minutes` int(11) NOT NULL DEFAULT 15,
  `session_timeout_minutes` int(11) NOT NULL DEFAULT 120,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `security_settings` VALUES ('1', '0', '0', '8', '1', '1', '0', '90', '5', '15', '120', '2026-02-23 20:04:51', '2026-02-23 20:04:51');

-- Table: sessions
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: stock_movements
DROP TABLE IF EXISTS `stock_movements`;
CREATE TABLE `stock_movements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` enum('purchase','sale','adjustment','damage','return','initial') NOT NULL,
  `quantity` int(11) NOT NULL,
  `previous_stock` int(11) NOT NULL,
  `new_stock` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_user_id_foreign` (`user_id`),
  KEY `stock_movements_product_id_created_at_index` (`product_id`,`created_at`),
  KEY `stock_movements_type_created_at_index` (`type`,`created_at`),
  KEY `stock_movements_created_at_index` (`created_at`),
  KEY `stock_movements_product_id_type_index` (`product_id`,`type`),
  CONSTRAINT `stock_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_movements_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_movements` VALUES ('1', '1', '1', 'sale', '-2', '150', '148', 'Sale: SALE-2026-0001', NULL, '2026-02-19 14:17:47', '2026-02-19 14:17:47');
INSERT INTO `stock_movements` VALUES ('2', '2', '1', 'sale', '-5', '80', '75', 'Sale: SALE-2026-0001', NULL, '2026-02-19 14:17:47', '2026-02-19 14:17:47');
INSERT INTO `stock_movements` VALUES ('3', '3', '1', 'initial', '1', '0', '1', NULL, '1000.00', '2026-02-19 17:33:36', '2026-02-19 17:33:36');
INSERT INTO `stock_movements` VALUES ('4', '3', '1', 'purchase', '14', '1', '15', NULL, '800.00', '2026-02-19 18:01:04', '2026-02-19 18:01:04');
INSERT INTO `stock_movements` VALUES ('5', '3', '1', 'sale', '-1', '15', '14', 'Sale: SALE-2026-0002', NULL, '2026-02-19 18:22:44', '2026-02-19 18:22:44');
INSERT INTO `stock_movements` VALUES ('6', '4', '1', 'initial', '1', '0', '1', NULL, '2000000.00', '2026-02-19 18:32:21', '2026-02-19 18:32:21');
INSERT INTO `stock_movements` VALUES ('7', '4', '1', 'purchase', '1', '1', '2', 'Received from PO: PO-2026-0003', '1800000.00', '2026-02-19 19:28:51', '2026-02-19 19:28:51');
INSERT INTO `stock_movements` VALUES ('8', '3', '1', 'purchase', '14', '14', '28', 'Received from PO: PO-2026-0001', '0.00', '2026-02-19 19:39:06', '2026-02-19 19:39:06');
INSERT INTO `stock_movements` VALUES ('9', '3', '1', 'purchase', '5', '28', '33', 'Received from PO: PO-2026-0004', '800.00', '2026-02-19 19:40:20', '2026-02-19 19:40:20');
INSERT INTO `stock_movements` VALUES ('10', '2', '1', 'purchase', '5', '75', '80', 'Received from PO: PO-2026-0002', '1800.00', '2026-02-19 19:41:50', '2026-02-19 19:41:50');
INSERT INTO `stock_movements` VALUES ('11', '4', '1', 'sale', '-1', '2', '1', 'Sale: SALE-2026-0003', NULL, '2026-02-19 19:43:52', '2026-02-19 19:43:52');
INSERT INTO `stock_movements` VALUES ('12', '2', '1', 'purchase', '100', '80', '180', 'Received from PO: PO-2026-0005', '1800.00', '2026-02-20 14:59:04', '2026-02-20 14:59:04');
INSERT INTO `stock_movements` VALUES ('13', '2', '1', 'sale', '-50', '180', '130', 'Sale: SALE-2026-0004', NULL, '2026-02-20 20:21:59', '2026-02-20 20:21:59');
INSERT INTO `stock_movements` VALUES ('14', '4', '1', 'purchase', '1', '1', '2', 'Received from PO: PO-2026-0006', '1800000.00', '2026-02-20 20:27:00', '2026-02-20 20:27:00');
INSERT INTO `stock_movements` VALUES ('15', '5', '1', 'initial', '10', '0', '10', NULL, '2000.00', '2026-02-20 21:41:14', '2026-02-20 21:41:14');
INSERT INTO `stock_movements` VALUES ('16', '5', '1', 'purchase', '5', '10', '15', NULL, '2000.00', '2026-02-20 21:42:17', '2026-02-20 21:42:17');
INSERT INTO `stock_movements` VALUES ('17', '5', '1', 'purchase', '100', '15', '115', 'Received from PO: PO-2026-0010', '2000.00', '2026-02-22 20:05:32', '2026-02-22 20:05:32');
INSERT INTO `stock_movements` VALUES ('18', '5', '1', 'purchase', '100', '115', '215', 'Received from PO: PO-2026-0009', '700.00', '2026-02-22 20:09:58', '2026-02-22 20:09:58');
INSERT INTO `stock_movements` VALUES ('19', '5', '1', 'purchase', '100', '215', '315', 'Received from PO: PO-2026-0008', '0.00', '2026-02-22 20:24:12', '2026-02-22 20:24:12');
INSERT INTO `stock_movements` VALUES ('20', '2', '1', 'purchase', '20', '130', '150', 'Received from PO: PO-2026-0007', '1800.00', '2026-02-22 20:24:50', '2026-02-22 20:24:50');
INSERT INTO `stock_movements` VALUES ('21', '7', '1', 'purchase', '50', '0', '50', 'Received from PO: PO-2026-0011', '13500.00', '2026-02-22 20:46:48', '2026-02-22 20:46:48');
INSERT INTO `stock_movements` VALUES ('22', '5', '1', 'purchase', '1', '315', '316', 'Received from PO: PO-2026-0013', '2000.00', '2026-02-23 14:32:07', '2026-02-23 14:32:07');
INSERT INTO `stock_movements` VALUES ('23', '6', '1', 'purchase', '5', '0', '5', 'Received from PO: PO-2026-0014', '65000.00', '2026-02-23 14:47:10', '2026-02-23 14:47:10');
INSERT INTO `stock_movements` VALUES ('24', '8', '1', 'purchase', '10', '0', '10', 'Received from PO: PO-2026-0015', '50000.00', '2026-02-23 15:46:19', '2026-02-23 15:46:19');
INSERT INTO `stock_movements` VALUES ('25', '9', '1', 'purchase', '5', '0', '5', 'Received from PO: PO-2026-0016', '48000.00', '2026-02-23 18:32:19', '2026-02-23 18:32:19');
INSERT INTO `stock_movements` VALUES ('26', '9', '1', 'sale', '-1', '5', '4', 'Sale: SALE-2026-0005', NULL, '2026-02-23 20:17:39', '2026-02-23 20:17:39');
INSERT INTO `stock_movements` VALUES ('27', '8', '1', 'purchase', '1', '10', '11', 'Received from PO: PO-2026-0017', '65000.00', '2026-02-24 15:01:54', '2026-02-24 15:01:54');
INSERT INTO `stock_movements` VALUES ('28', '8', '1', 'purchase', '1', '11', '12', 'Received from PO: PO-2026-0018', '60000.00', '2026-02-24 15:32:39', '2026-02-24 15:32:39');
INSERT INTO `stock_movements` VALUES ('29', '5', '1', 'purchase', '1', '316', '317', 'Received from PO: PO-2026-0019', '1950.00', '2026-02-27 22:54:03', '2026-02-27 22:54:03');
INSERT INTO `stock_movements` VALUES ('30', '10', '1', 'purchase', '5', '0', '5', 'Received from PO: PO-2026-0021', '5000.00', '2026-03-01 16:29:06', '2026-03-01 16:29:06');
INSERT INTO `stock_movements` VALUES ('31', '11', '1', 'purchase', '1', '0', '1', 'Received from PO: PO-2026-0022', '1500.00', '2026-03-01 19:31:14', '2026-03-01 19:31:14');

-- Table: stock_transfers
DROP TABLE IF EXISTS `stock_transfers`;
CREATE TABLE `stock_transfers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transfer_number` varchar(255) NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `from_department_id` bigint(20) unsigned NOT NULL,
  `to_department_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `requested_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `received_by` bigint(20) unsigned DEFAULT NULL,
  `status` enum('pending','approved','in_transit','received','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_transfers_transfer_number_unique` (`transfer_number`),
  KEY `stock_transfers_product_id_foreign` (`product_id`),
  KEY `stock_transfers_to_department_id_foreign` (`to_department_id`),
  KEY `stock_transfers_requested_by_foreign` (`requested_by`),
  KEY `stock_transfers_approved_by_foreign` (`approved_by`),
  KEY `stock_transfers_received_by_foreign` (`received_by`),
  KEY `stock_transfers_transfer_number_index` (`transfer_number`),
  KEY `stock_transfers_status_index` (`status`),
  KEY `stock_transfers_from_department_id_to_department_id_index` (`from_department_id`,`to_department_id`),
  CONSTRAINT `stock_transfers_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `stock_transfers_from_department_id_foreign` FOREIGN KEY (`from_department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `stock_transfers_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_transfers_received_by_foreign` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`),
  CONSTRAINT `stock_transfers_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  CONSTRAINT `stock_transfers_to_department_id_foreign` FOREIGN KEY (`to_department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: suppliers
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `phone_alt` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'Nigeria',
  `payment_terms` enum('cash','bank_transfer','cheque','card','credit','credit_7','credit_14','credit_30','credit_60','custom') NOT NULL DEFAULT 'cash',
  `custom_payment_days` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppliers_code_unique` (`code`),
  KEY `suppliers_name_index` (`name`),
  KEY `suppliers_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `suppliers` VALUES ('1', 'MedSupply Nigeria Ltd', 'SUP-001', 'John Okafor', 'contact@medsupply.ng', '+234 803 123 4567', NULL, '12 Medical Road, Ikeja, Lagos', 'Lagos', 'Lagos', 'Nigeria', 'credit_30', NULL, NULL, '1', '2026-02-19 16:22:09', '2026-02-18 17:35:08', '2026-02-19 16:22:09');
INSERT INTO `suppliers` VALUES ('2', 'Global Foods Distribution', 'SUP-002', 'Mary Adeyemi', 'sales@globalfoods.ng', '+234 805 987 6543', NULL, '45 Commerce Avenue, VI, Lagos', 'Lagos', 'Lagos', 'Nigeria', 'credit_14', NULL, NULL, '1', NULL, '2026-02-18 17:35:08', '2026-02-18 17:35:08');
INSERT INTO `suppliers` VALUES ('3', 'NDA Watu Store', 'SUP-2026-0001', 'Isah Ali Al-Mustapha', 'isahialmustapha@gmail.com', '08033333333', NULL, 'Ran road, Muda Lawal Junction', NULL, NULL, 'Nigeria', 'card', NULL, NULL, '1', NULL, '2026-02-19 16:33:29', '2026-02-19 18:33:50');
INSERT INTO `suppliers` VALUES ('4', 'Mai Zanen Goshi', 'SUP-2026-0002', 'Alhaji Mai Zanengoshi', 'maizanengoshi@gmail.com', '0803435363738', NULL, 'Central Market, Bauchi', NULL, NULL, 'Nigeria', 'custom', NULL, NULL, '1', NULL, '2026-02-19 16:35:16', '2026-02-19 16:35:16');
INSERT INTO `suppliers` VALUES ('5', 'Golden Fabrics Lagos', 'SUP-2026-0003', 'Nwachuku Chibuzor', 'buzor@lagosfabrics.com', '0803435363738', NULL, 'Alaba Market Lagos.', NULL, NULL, 'Nigeria', 'cash', NULL, NULL, '1', NULL, '2026-02-23 15:43:41', '2026-02-23 15:43:41');
INSERT INTO `suppliers` VALUES ('6', 'Gwaram Baby Care', 'SUP-2026-0004', 'Sabo Gwaram', 'gwarambabycare@gmail.com', '0803435363738', NULL, NULL, 'Bauchi', 'Bauchi', 'Nigeria', 'bank_transfer', NULL, NULL, '1', NULL, '2026-02-23 18:02:42', '2026-02-23 18:30:11');

-- Table: two_factor_auth
DROP TABLE IF EXISTS `two_factor_auth`;
CREATE TABLE `two_factor_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `secret` varchar(255) DEFAULT NULL,
  `recovery_codes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`recovery_codes`)),
  `enabled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `two_factor_auth_user_id_unique` (`user_id`),
  CONSTRAINT `two_factor_auth_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `role` enum('master_admin','section_head') NOT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `locked_until` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_index` (`role`),
  KEY `users_department_id_index` (`department_id`),
  KEY `users_role_is_active_index` (`role`,`is_active`),
  CONSTRAINT `users_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1', 'Master Admin', 'admin@alkhair.com', NULL, NULL, '$2y$12$jSkJM.G9lfRpVRSzmk8HOOnpIzFzdjNTl5O7WgnK/x4k/9I.iikz.', NULL, 'master_admin', NULL, '1', NULL, NULL, '2026-02-18 17:33:47', '2026-02-18 17:33:47');
INSERT INTO `users` VALUES ('2', 'Pharmacy Manager', 'pharmacy@alkhair.com', NULL, NULL, '$2y$12$u7NkViAwXQtq8iBVHDBrdegiGiF5qlHe9Z7ruUUNV2Lu3QeNeCJrK', NULL, 'section_head', '1', '1', NULL, NULL, '2026-02-18 17:33:47', '2026-02-18 17:33:47');
INSERT INTO `users` VALUES ('3', 'Superstore Manager', 'superstore@alkhair.com', NULL, NULL, '$2y$12$APwu5hKCb0t8H3KdWd5WH.ciuVOyrjmXSsggzV0EZArf4cBtMvW9O', NULL, 'section_head', '2', '1', NULL, NULL, '2026-02-18 17:33:47', '2026-02-18 17:33:47');

-- Table: webhook_deliveries
DROP TABLE IF EXISTS `webhook_deliveries`;
CREATE TABLE `webhook_deliveries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` bigint(20) unsigned NOT NULL,
  `event` varchar(255) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `response_code` int(11) DEFAULT NULL,
  `response_body` text DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `delivered_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_deliveries_webhook_id_delivered_at_index` (`webhook_id`,`delivered_at`),
  CONSTRAINT `webhook_deliveries_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: webhooks
DROP TABLE IF EXISTS `webhooks`;
CREATE TABLE `webhooks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `events` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`events`)),
  `secret` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: wishlists
DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE `wishlists` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_customer_id_product_id_unique` (`customer_id`,`product_id`),
  KEY `wishlists_product_id_foreign` (`product_id`),
  CONSTRAINT `wishlists_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
